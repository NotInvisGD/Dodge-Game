import pygame
import random

pygame.init()

WIDTH, HEIGHT = 800, 600
FPS = 60
score = 0
sound = pygame.mixer.Sound("fire-in-the-hole-geometry-dash.mp3")

WHITE = (255, 255, 255)
RED = (255, 0, 0)
ORANGE = (255, 165, 0)
BLACK = (0, 0, 0)

player = pygame.Rect(400, 400, 50, 50)
ball = pygame.Rect(random.randint(35, WIDTH - 35), 0, 35, 35)

player_velocity = 7

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Dodge Game")

run = True
clock = pygame.time.Clock()

def player_movement():
    key_pressed = pygame.key.get_pressed()
    
    if key_pressed[pygame.K_a] and player.x > 0:
        player.x -= player_velocity
    if key_pressed[pygame.K_d] and player.x < WIDTH - player.width:
        player.x += player_velocity

def drawing(score):
    font_2 = pygame.font.SysFont(None, 35)
    score_display = font_2.render(f"Score: {score}", True, (BLACK))
    screen.blit(score_display, (10, 50))
             
while run:
    screen.fill(WHITE)
    pygame.draw.rect(screen, (RED), player)
    pygame.draw.ellipse(screen, (ORANGE), ball)
    
    font = pygame.font.SysFont(None, 60)
    game_over_display = font.render("Game Over!", True, (BLACK))
    
    ball.y += 6
    
    if ball.y > HEIGHT:
        score += 1
        ball.y = 0
        ball.x = random.randint(35, WIDTH - 35)
    
    if ball.colliderect(player):
        sound.play()
        print ("")
        screen.blit(game_over_display, (WIDTH//2 - 100, HEIGHT//2 - 60))
        pygame.display.flip()
        pygame.time.wait(2000)
        break
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    
    drawing(score)
    player_movement()
    pygame.display.flip()
    clock.tick(FPS)
pygame.quit()